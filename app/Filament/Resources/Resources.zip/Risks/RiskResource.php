<?php

namespace App\Filament\Resources\Risks;

use App\Filament\Resources\BaseResource;
use App\Filament\Resources\Risks\Pages;
use App\Filament\Resources\Risks\Schemas\RiskForm;
use App\Filament\Resources\Risks\Tables\RisksTable;
use App\Models\Tmrisk;
use BackedEnum;
use Filament\Schemas\Schema;
use Filament\Tables\Table;
use UnitEnum;

class RiskResource extends BaseResource
{
    protected static ?string $model = Tmrisk::class;

    protected static ?string $menuCode = 'risk';

    protected static UnitEnum|string|null $navigationGroup = 'Risk';
    protected static ?string $navigationLabel = 'Risk Register';
    protected static ?string $modelLabel = 'Risk Register';
    protected static ?string $pluralModelLabel = 'Risk Register';

    protected static BackedEnum|string|null $navigationIcon = 'heroicon-o-clipboard-document-list';
    protected static ?int $navigationSort = 5;

    protected static ?string $recordTitleAttribute = 'i_risk';

    public static function form(Schema $schema): Schema
    {
        return RiskForm::configure($schema);
    }

    public static function table(Table $table): Table
    {
        return RisksTable::configure($table);
    }

    public static function getPages(): array
    {
        return [
            'index'  => Pages\ListRisks::route('/'),
            'create' => Pages\CreateRisk::route('/create'),
            'edit'   => Pages\EditRisk::route('/{record}/edit'),
            'view'   => Pages\ViewRisk::route('/{record}'),
        ];
    }
}
