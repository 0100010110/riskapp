<?php

namespace App\Filament\Resources\RiskApprovals\Schemas;

use App\Models\Tmrisk;
use App\Models\Tmriskapprove;
use App\Models\Trrole;
use App\Support\RiskApprovalWorkflow;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Schema;
use Illuminate\Database\Eloquent\Builder;

class RiskApprovalForm
{
    private const SESSION_LOCK_RISK_KEY = 'risk_approval.locked_risk_id';

    public static function configure(Schema $schema): Schema
    {
        $ctx = RiskApprovalWorkflow::context();

        /**
         * ✅ FIX: query param ?risk hanya ada saat initial GET.
         * Saat Livewire submit, query hilang -> risk bisa dianggap invalid.
         * Solusi: lock riskId di session.
         */
        $riskIdFromRequest = 0;
        try {
            $riskIdFromRequest = (int) request()->query('risk', 0);
        } catch (\Throwable) {
            $riskIdFromRequest = 0;
        }

        // GET tanpa ?risk => clear lock agar tidak nyangkut tab lain
        try {
            if (request()->isMethod('GET') && $riskIdFromRequest <= 0) {
                session()->forget(self::SESSION_LOCK_RISK_KEY);
            }
        } catch (\Throwable) {
        }

        // jika ada ?risk, simpan; jika tidak ada (Livewire), ambil dari session lock
        try {
            if ($riskIdFromRequest > 0) {
                session()->put(self::SESSION_LOCK_RISK_KEY, $riskIdFromRequest);
            } else {
                $riskIdFromRequest = (int) session()->get(self::SESSION_LOCK_RISK_KEY, 0);
            }
        } catch (\Throwable) {
        }

        /**
         * ✅ Pickable statuses sesuai workflow nyata.
         * - superadmin: 0..17
         * - non-superadmin: sesuai role_type
         */
        $pickableStatuses = RiskApprovalWorkflow::actionableStatusesForCurrentUser();

        // role approver id (superadmin 2542 sudah resolved ke role SuperAdmin by string di RiskApprovalWorkflow)
        $roleId = RiskApprovalWorkflow::currentApproverRoleId();

        return $schema
            ->columns(['default' => 1, 'lg' => 1])
            ->schema([
                Section::make('Risk Approval')
                    ->columnSpanFull()
                    ->columns(2)
                    ->schema([
                        Select::make('i_id_risk')
                            ->label('Risk')
                            ->relationship(
                                name: 'risk',
                                titleAttribute: 'i_risk',
                                modifyQueryUsing: function (Builder $query) use ($pickableStatuses, $riskIdFromRequest) {
                                    $query->where(function (Builder $q) use ($pickableStatuses, $riskIdFromRequest) {
                                        // tampilkan yang sesuai status workflow
                                        if (! empty($pickableStatuses)) {
                                            $q->whereIn('c_risk_status', $pickableStatuses);
                                        } else {
                                            // kalau role tidak punya status actionable, jangan tampilkan apa-apa
                                            $q->whereRaw('1=0');
                                        }

                                        // ✅ jika risk dikunci dari URL/session, tetap masukkan ke opsi
                                        if ($riskIdFromRequest > 0) {
                                            $q->orWhere('i_id_risk', $riskIdFromRequest);
                                        }
                                    });

                                    // scope list sesuai role (org prefix, dll)
                                    RiskApprovalWorkflow::applyApprovalListScope($query);

                                    return $query
                                        ->orderByDesc('c_risk_year')
                                        ->orderBy('i_risk');
                                },
                            )
                            ->getOptionLabelFromRecordUsing(function (Tmrisk $record): string {
                                $event = trim((string) $record->e_risk_event);
                                $event = mb_strlen($event) > 60 ? (mb_substr($event, 0, 60) . '…') : $event;

                                return "{$record->c_risk_year} - {$record->i_risk} | {$event}";
                            })
                            ->searchable()
                            ->preload()
                            ->required()
                            ->default(fn (?Tmriskapprove $record) => $record?->i_id_risk ?: ($riskIdFromRequest > 0 ? $riskIdFromRequest : null))
                            ->afterStateHydrated(function (Select $component) use ($riskIdFromRequest) {
                                if ($riskIdFromRequest > 0) {
                                    $component->state($riskIdFromRequest);
                                }
                            })
                            // jika risk dikunci, jangan bisa diganti
                            ->disabled(fn () => $riskIdFromRequest > 0)
                            ->dehydrated(true),

                        Select::make('i_id_role')
                            ->label('Role (Approver)')
                            ->relationship(
                                name: 'role',
                                titleAttribute: 'n_role',
                                modifyQueryUsing: fn (Builder $query) => $query->where('f_active', true),
                            )
                            ->getOptionLabelFromRecordUsing(fn (Trrole $record) => "{$record->c_role} - {$record->n_role}")
                            // ✅ agar label tetap tampil meskipun option belum kepreload
                            ->getOptionLabelUsing(function ($value): ?string {
                                $id = (int) $value;
                                if ($id <= 0) return null;

                                $r = Trrole::query()
                                    ->select(['c_role', 'n_role'])
                                    ->where('i_id_role', $id)
                                    ->first();

                                return $r ? "{$r->c_role} - {$r->n_role}" : null;
                            })
                            ->searchable()
                            ->preload()
                            ->required()
                            ->default(fn (?Tmriskapprove $record) => $record?->i_id_role ?: $roleId)
                            ->afterStateHydrated(function (Select $component) use ($roleId) {
                                if (! $component->getState() && $roleId) {
                                    $component->state($roleId);
                                }
                            })
                            ->disabled()
                            ->dehydrated(true),

                        TextInput::make('i_emp')
                            ->label('Approved By (NIK)')
                            ->required()
                            ->maxLength(50)
                            ->default(fn (?Tmriskapprove $record) => $record?->i_emp ?: RiskApprovalWorkflow::currentUserNik())
                            ->dehydrated(true),

                        TextInput::make('n_emp')
                            ->label('Approved By (Name)')
                            ->required()
                            ->maxLength(255)
                            ->default(fn (?Tmriskapprove $record) => $record?->n_emp ?: RiskApprovalWorkflow::currentUserName())
                            ->dehydrated(true),
                    ]),
            ]);
    }
}
